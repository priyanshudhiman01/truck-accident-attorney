import type { Lawyer, Location, MapBounds } from '../types';
import { googleMapsLoader } from './GoogleMapsLoader';

let placesService: google.maps.places.PlacesService;

const initPlacesService = async () => {
  if (!placesService) {
    await googleMapsLoader.load();
    const mapDiv = document.createElement('div');
    const map = new google.maps.Map(mapDiv, {
      center: { lat: 0, lng: 0 },
      zoom: 1
    });
    placesService = new google.maps.places.PlacesService(map);
  }
  return placesService;
};

const convertToLawyer = (place: google.maps.places.PlaceResult): Lawyer => {
  return {
    id: place.place_id!,
    name: place.name!,
    imageUrl: place.photos?.[0]?.getUrl() || 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80&w=800',
    location: {
      address: place.formatted_address!,
      city: place.address_components?.find(c => c.types.includes('locality'))?.long_name || '',
      state: place.address_components?.find(c => c.types.includes('administrative_area_level_1'))?.long_name || '',
      coords: {
        lat: place.geometry!.location!.lat(),
        lng: place.geometry!.location!.lng()
      }
    },
    specializations: ['Truck Accidents', 'Personal Injury'],
    rating: place.rating || 0,
    totalRatings: place.user_ratings_total || 0,
    contact: {
      phone: place.formatted_phone_number || '',
      website: place.website
    },
    placeId: place.place_id!,
    photos: place.photos?.map(photo => photo.getUrl()) || []
  };
};

export const searchLawyers = async (
  query: string,
  bounds?: MapBounds,
  nextPageToken?: string
): Promise<{ lawyers: Lawyer[]; nextPageToken?: string }> => {
  const service = await initPlacesService();

  const request: google.maps.places.TextSearchRequest = {
    query: `${query} truck accident lawyer`,
    type: 'lawyer'
  };

  if (bounds) {
    request.bounds = new google.maps.LatLngBounds(
      new google.maps.LatLng(bounds.sw.lat, bounds.sw.lng),
      new google.maps.LatLng(bounds.ne.lat, bounds.ne.lng)
    );
  }

  return new Promise((resolve, reject) => {
    service.textSearch(
      { ...request, pageToken: nextPageToken },
      (results, status, pagination) => {
        if (status === google.maps.places.PlacesServiceStatus.OK && results) {
          const lawyers = results.map(convertToLawyer);
          resolve({
            lawyers,
            nextPageToken: pagination?.hasNextPage ? pagination.nextPageToken : undefined
          });
        } else {
          reject(new Error(`Places API error: ${status}`));
        }
      }
    );
  });
};