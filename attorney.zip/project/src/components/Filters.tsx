import React from 'react';
import type { SearchFilters } from '../types';

interface FiltersProps {
  filters: SearchFilters;
  onFilterChange: (filters: SearchFilters) => void;
}

export function Filters({ filters, onFilterChange }: FiltersProps) {
  const specializations = [
    'Truck Accidents',
    'Personal Injury',
    'Insurance Claims',
    'Wrongful Death'
  ];

  const handleSpecializationChange = (spec: string, checked: boolean) => {
    onFilterChange({
      ...filters,
      specialization: checked
        ? [...filters.specialization, spec]
        : filters.specialization.filter(s => s !== spec)
    });
  };

  return (
    <div className="space-y-6 p-6 bg-white rounded-lg shadow-sm sticky top-20">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Minimum Rating</h3>
        <select
          className="w-full p-2 border rounded-md"
          value={filters.rating}
          onChange={(e) => onFilterChange({
            ...filters,
            rating: Number(e.target.value)
          })}
        >
          <option value="0">Any Rating</option>
          <option value="3">3+ Stars</option>
          <option value="4">4+ Stars</option>
          <option value="4.5">4.5+ Stars</option>
        </select>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Specialization</h3>
        <div className="space-y-2">
          {specializations.map((spec) => (
            <label key={spec} className="flex items-center">
              <input
                type="checkbox"
                className="form-checkbox h-4 w-4 text-blue-600 rounded"
                checked={filters.specialization.includes(spec)}
                onChange={(e) => handleSpecializationChange(spec, e.target.checked)}
              />
              <span className="ml-2 text-gray-700">{spec}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
}