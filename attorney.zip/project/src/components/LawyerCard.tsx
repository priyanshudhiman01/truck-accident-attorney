import React from 'react';
import { Phone, Globe, Star, MapPin, Clock } from 'lucide-react';
import type { Lawyer } from '../types';

interface LawyerCardProps {
  lawyer: Lawyer;
  onSelect: () => void;
  selected: boolean;
}

export function LawyerCard({ lawyer, onSelect, selected }: LawyerCardProps) {
  return (
    <div 
      className={`
        bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all cursor-pointer
        transform hover:-translate-y-1 duration-200
        ${selected ? 'ring-2 ring-blue-500' : ''}
      `}
      onClick={onSelect}
    >
      <div className="relative h-48">
        <img
          src={lawyer.imageUrl}
          alt={lawyer.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full shadow-sm flex items-center">
          <Star className="h-4 w-4 text-yellow-400 fill-current" />
          <span className="ml-1 text-sm font-medium">{lawyer.rating.toFixed(1)}</span>
          <span className="ml-1 text-xs text-gray-500">({lawyer.totalRatings})</span>
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-2 line-clamp-1">{lawyer.name}</h3>
        
        <div className="flex items-center text-gray-600 mb-4">
          <MapPin className="h-4 w-4 mr-2 flex-shrink-0 text-blue-500" />
          <p className="text-sm line-clamp-1">{lawyer.location.address}</p>
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          {lawyer.specializations.map((spec) => (
            <span
              key={spec}
              className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-xs font-medium"
            >
              {spec}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}