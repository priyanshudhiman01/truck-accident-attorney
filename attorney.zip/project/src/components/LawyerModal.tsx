import React from 'react';
import { X, Phone, Globe, Star, MapPin, Clock, Mail, ExternalLink } from 'lucide-react';
import type { Lawyer } from '../types';

interface LawyerModalProps {
  lawyer: Lawyer;
  onClose: () => void;
}

export function LawyerModal({ lawyer, onClose }: LawyerModalProps) {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <div className="relative">
          <button
            onClick={onClose}
            className="absolute right-4 top-4 p-2 bg-white/90 backdrop-blur-sm rounded-full shadow-lg z-10 hover:bg-white transition-colors"
          >
            <X className="h-5 w-5 text-gray-600" />
          </button>
          
          <div className="h-48 sm:h-64 relative">
            <img
              src={lawyer.imageUrl}
              alt={lawyer.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
              <h2 className="text-xl sm:text-2xl font-bold text-white">{lawyer.name}</h2>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          <div className="flex items-center gap-4">
            <div className="bg-white px-4 py-2 rounded-full shadow-sm flex items-center">
              <Star className="h-5 w-5 text-yellow-400 fill-current" />
              <span className="ml-1 font-medium">{lawyer.rating.toFixed(1)}</span>
              <a
                href={`https://www.google.com/maps/place/?q=place_id:${lawyer.placeId}`}
                target="_blank"
                rel="noopener noreferrer"
                className="ml-2 text-sm text-blue-600 hover:text-blue-800 flex items-center"
              >
                {lawyer.totalRatings} reviews
                <ExternalLink className="h-3 w-3 ml-1" />
              </a>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-blue-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-medium text-gray-900">Address</h3>
                <p className="text-gray-600">{lawyer.location.address}</p>
              </div>
            </div>

            {lawyer.contact.phone && (
              <div className="flex items-start gap-3">
                <Phone className="h-5 w-5 text-blue-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-medium text-gray-900">Phone</h3>
                  <a
                    href={`tel:${lawyer.contact.phone}`}
                    className="text-blue-600 hover:text-blue-800 flex items-center"
                  >
                    {lawyer.contact.phone}
                  </a>
                </div>
              </div>
            )}

            {lawyer.contact.email && (
              <div className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-blue-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-medium text-gray-900">Email</h3>
                  <a
                    href={`mailto:${lawyer.contact.email}`}
                    className="text-blue-600 hover:text-blue-800 flex items-center"
                  >
                    {lawyer.contact.email}
                  </a>
                </div>
              </div>
            )}

            {lawyer.contact.website && (
              <div className="flex items-start gap-3">
                <Globe className="h-5 w-5 text-blue-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-medium text-gray-900">Website</h3>
                  <a
                    href={lawyer.contact.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-800 flex items-center"
                  >
                    Visit Website
                    <ExternalLink className="h-3 w-3 ml-1" />
                  </a>
                </div>
              </div>
            )}

            {lawyer.openingHours && (
              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-blue-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-medium text-gray-900">Opening Hours</h3>
                  <div className="text-gray-600">
                    {lawyer.openingHours.map((hours, index) => (
                      <div key={index}>{hours}</div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          <div>
            <h3 className="font-medium text-gray-900 mb-2">Specializations</h3>
            <div className="flex flex-wrap gap-2">
              {lawyer.specializations.map((spec) => (
                <span
                  key={spec}
                  className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm"
                >
                  {spec}
                </span>
              ))}
            </div>
          </div>

          {lawyer.photos.length > 0 && (
            <div>
              <h3 className="font-medium text-gray-900 mb-3">Photos</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {lawyer.photos.slice(0, 6).map((photo, index) => (
                  <img
                    key={index}
                    src={photo}
                    alt={`${lawyer.name} photo ${index + 1}`}
                    className="w-full h-24 object-cover rounded-lg"
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}