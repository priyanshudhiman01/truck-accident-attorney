import React, { useState, useCallback, useEffect } from 'react';
import { useInView } from 'react-intersection-observer';
import { Header } from './components/Header';
import { SearchBar } from './components/SearchBar';
import { Filters } from './components/Filters';
import { LawyerCard } from './components/LawyerCard';
import { LawyerModal } from './components/LawyerModal';
import { Map } from './components/Map';
import { SeoContent } from './components/SeoContent';
import { searchLawyers } from './services/GooglePlacesService';
import type { Lawyer, SearchFilters, Location, MapBounds } from './types';

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [lawyers, setLawyers] = useState<Lawyer[]>([]);
  const [loading, setLoading] = useState(false);
  const [nextPageToken, setNextPageToken] = useState<string>();
  const [selectedLawyer, setSelectedLawyer] = useState<Lawyer>();
  const [mapBounds, setMapBounds] = useState<MapBounds>();
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<SearchFilters>({
    specialization: [],
    rating: 0,
    sortBy: 'rating'
  });

  const { ref: loadMoreRef, inView } = useInView({
    threshold: 0.5,
    triggerOnce: false
  });

  const handleSearch = useCallback(async (query: string) => {
    setSearchQuery(query);
    setLoading(true);
    try {
      const result = await searchLawyers(query, mapBounds);
      setLawyers(result.lawyers);
      setNextPageToken(result.nextPageToken);
    } catch (error) {
      console.error('Error searching lawyers:', error);
    } finally {
      setLoading(false);
    }
  }, [mapBounds]);

  const handleLoadMore = useCallback(async () => {
    if (!nextPageToken || loading) return;
    
    setLoading(true);
    try {
      const result = await searchLawyers(searchQuery, mapBounds, nextPageToken);
      setLawyers(prev => [...prev, ...result.lawyers]);
      setNextPageToken(result.nextPageToken);
    } catch (error) {
      console.error('Error loading more lawyers:', error);
    } finally {
      setLoading(false);
    }
  }, [nextPageToken, loading, searchQuery, mapBounds]);

  const handleBoundsChanged = (ne: Location, sw: Location) => {
    setMapBounds({ ne, sw });
  };

  useEffect(() => {
    if (inView) {
      handleLoadMore();
    }
  }, [inView, handleLoadMore]);

  const filteredLawyers = lawyers.filter(lawyer => {
    const matchesRating = lawyer.rating >= filters.rating;
    const matchesSpecialization = filters.specialization.length === 0 ||
      lawyer.specializations.some(s => filters.specialization.includes(s));

    return matchesRating && matchesSpecialization;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Hero Section */}
      <div className="min-h-screen relative flex items-center justify-center pt-16">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-white to-purple-50" />
          <div className="absolute inset-0" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%234299e1' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }} />
        </div>

        <div className="relative z-10 text-center px-4 max-w-6xl mx-auto">
          <div className="mb-12">
            <h1 className="text-4xl md:text-7xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600 mb-6">
              Find Your Truck Accident Lawyer
            </h1>
            <p className="text-lg md:text-xl text-gray-600 mb-12 max-w-3xl mx-auto">
              Connect with experienced truck accident attorneys who can help you get the compensation you deserve.
            </p>
          </div>
          
          <SearchBar onSearch={handleSearch} />
        </div>
      </div>

      {/* SEO Content or Results Section */}
      {!searchQuery ? (
        <SeoContent />
      ) : (
        <main id="results-section" className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
          <div className="mb-8">
            <Map 
              lawyers={filteredLawyers}
              onBoundsChanged={handleBoundsChanged}
              selectedLawyer={selectedLawyer}
            />
          </div>

          {/* Mobile Filters Toggle */}
          <div className="lg:hidden mb-6">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="w-full px-4 py-2 bg-white rounded-lg shadow-sm text-gray-700 font-medium flex items-center justify-center"
            >
              {showFilters ? 'Hide Filters' : 'Show Filters'}
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Filters */}
            <div className={`lg:col-span-1 ${showFilters || 'hidden lg:block'}`}>
              <Filters 
                filters={filters}
                onFilterChange={setFilters}
              />
            </div>

            {/* Lawyer Cards */}
            <div className="lg:col-span-3">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredLawyers.map(lawyer => (
                  <LawyerCard 
                    key={lawyer.id}
                    lawyer={lawyer}
                    onSelect={() => setSelectedLawyer(lawyer)}
                    selected={selectedLawyer?.id === lawyer.id}
                  />
                ))}
              </div>

              {nextPageToken && (
                <div 
                  ref={loadMoreRef}
                  className="mt-8 text-center"
                >
                  {loading && (
                    <div className="inline-flex items-center px-4 py-2 text-sm text-gray-700">
                      Loading more lawyers...
                    </div>
                  )}
                </div>
              )}

              {filteredLawyers.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-gray-500 text-lg">
                    No lawyers found matching your criteria. Try adjusting your filters.
                  </p>
                </div>
              )}
            </div>
          </div>
        </main>
      )}

      {/* Lawyer Modal */}
      {selectedLawyer && (
        <LawyerModal
          lawyer={selectedLawyer}
          onClose={() => setSelectedLawyer(undefined)}
        />
      )}

      {/* Footer */}
      <footer className="bg-white border-t">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">
                About
              </h3>
              <p className="mt-4 text-base text-gray-500">
                Connecting you with experienced truck accident lawyers across the United States.
              </p>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">
                Legal
              </h3>
              <ul className="mt-4 space-y-4">
                <li>
                  <a href="#" className="text-base text-gray-500 hover:text-gray-900">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="text-base text-gray-500 hover:text-gray-900">
                    Terms of Service
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">
                Contact
              </h3>
              <ul className="mt-4 space-y-4">
                <li>
                  <a href="#" className="text-base text-gray-500 hover:text-gray-900">
                    Support
                  </a>
                </li>
                <li>
                  <a href="#" className="text-base text-gray-500 hover:text-gray-900">
                    Contact Us
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;